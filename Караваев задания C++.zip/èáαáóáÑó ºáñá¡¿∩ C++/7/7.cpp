#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <cassert>

using namespace std;

class TsNet {
private:
    int N; // Количество остановок

    vector<vector<int>> routes; // Список маршрутов
    unordered_map<int, unordered_set<int>> stopToR; // Карта от остановки до проходящих через нее маршрутов

    void buildstopToR() {
        stopToR.clear();
        for (int i = 0; i < routes.size(); ++i) {
            for (int stop : routes[i]) {
                stopToR[stop].insert(i);
            }
        }
    }
    
    

    void bfs(int start, unordered_set<int>& visited, vector<vector<int>>& adjList) {
        queue<int> q;
        q.push(start);
        visited.insert(start);


        while (!q.empty()) {
            int current = q.front();
            q.pop();

            for (int neighbor : adjList[current]) {
                if (visited.find(neighbor) == visited.end()) {
                    visited.insert(neighbor);
                    q.push(neighbor);
                }
            }
        }
    }

    bool isGCon(vector<vector<int>>& adjList) {
        for (int i = 0; i < N; ++i) {
            unordered_set<int> visited;
            bfs(i, visited, adjList);
            if (visited.size() != N) {
                return false;
            }
        }
        return true;
    }

public:
    TsNet(int n, int m) : N(n) {
        routes.resize(m);
    }

    void addRoute(int index, const vector<int>& route) {
        routes[index] = route;
    }

    bool TraveloR(int start, int end) {
        for (const auto& route : routes) {
            auto it_start = find(route.begin(), route.end(), start);
            auto it_end = find(route.begin(), route.end(), end);
            if (it_start != route.end() && it_end != route.end() && it_start <= it_end) {
                return true;
            }
        }
        return false;
    }

    bool TraveloT(int start, int end, int maxTransfers) {
        buildstopToR();

        queue<pair<int, int>> q; //текущая остановка, количество пересадок
        unordered_set<int> visitedStops;
        q.push({start, 0});
        visitedStops.insert(start);

        while (!q.empty()) {
            int currentStop = q.front().first;
            int transfers = q.front().second;
            q.pop();

            if (currentStop == end) {
                return true;
            }

            if (transfers >= maxTransfers) {
                continue;
            }

            for (int route : stopToR[currentStop]) {
                for (int nextStop : routes[route]) {
                    if (visitedStops.find(nextStop) == visitedStops.end()) {
                        q.push({nextStop, transfers + 1});
                        visitedStops.insert(nextStop);
                    }
                }
            }
        }

        return false;
    }

    bool FullCon() {
        vector<vector<int>> adjList(N);
        for (const auto& route : routes) {
            for (int i = 0; i < route.size() - 1; ++i) {
                adjList[route[i]].push_back(route[i + 1]);
                adjList[route[i + 1]].push_back(route[i]);
            }
        }
        return isGCon(adjList);
    }

    bool FullConBes(int routeIndex) {
        vector<vector<int>> adjList(N);
        for (int i = 0; i < routes.size(); ++i) {
            if (i == routeIndex) continue;
            for (int j = 0; j < routes[i].size() - 1; ++j) {
                adjList[routes[i][j]].push_back(routes[i][j + 1]);
                adjList[routes[i][j + 1]].push_back(routes[i][j]);
            }
        }
        return isGCon(adjList);
    }

    int mRTD() {
        int minToRemove = routes.size();
        for (int i = 1; i < (1 << routes.size()); ++i) {
            vector<vector<int>> adjList(N);
            int removeCount = 0;

            for (int j = 0; j < routes.size(); ++j) {
                if (i & (1 << j)) {
                    removeCount++;
                    continue;
                }
                for (int k = 0; k < routes[j].size() - 1; ++k) {
                    adjList[routes[j][k]].push_back(routes[j][k + 1]);
                    adjList[routes[j][k + 1]].push_back(routes[j][k]);
                }
            }

            if (!isGCon(adjList)) {
                minToRemove = min(minToRemove, removeCount);
            }
        }

        return minToRemove;
    }

    void runTests() {
        //пример 1. базовая проверка подключения
        {
            TsNet tn(5, 3);
            tn.addRoute(0, {0, 1, 2, 3});
            tn.addRoute(1, {1, 4});
            tn.addRoute(2, {3, 4});
            assert(tn.TraveloR(0, 3) == true);
            assert(tn.TraveloR(0, 4) == false);
        }

        //пример 2. проверка переводов
        {
            TsNet tn(5, 3);
            tn.addRoute(0, {0, 1, 2, 3});
            tn.addRoute(1, {1, 4});
            tn.addRoute(2, {3, 4});
            assert(tn.TraveloT(0, 4, 1) == true);
            assert(tn.TraveloT(0, 4, 0) == false);
        }

        //пример 3. проверка полносвязности
        {
            TsNet tn(5, 3);
            tn.addRoute(0, {0, 1, 2, 3});
            tn.addRoute(1, {1, 4});
            tn.addRoute(2, {3, 4});
            assert(tn.FullCon() == true);
        }

        //пример 4. Удаление одного маршрута
        {
            TsNet tn(5, 3);
            tn.addRoute(0, {0, 1, 2, 3});
            tn.addRoute(1, {1, 4});
            tn.addRoute(2, {3, 4});
            assert(tn.FullConBes(0) == true);
            assert(tn.FullConBes(1) == true);
            assert(tn.FullConBes(2) == true);
        }

        //пример 5. нет возможного маршрута
        {
            TsNet tn(6, 2);
            tn.addRoute(0, {0, 1, 2});
            tn.addRoute(1, {3, 4, 5});
            assert(tn.FullCon() == false);
        }

        //пример 6. круговой маршрут
        {
            TsNet tn(5, 1);
            tn.addRoute(0, {0, 1, 2, 3, 0});
            assert(tn.FullCon() == true);
            assert(tn.FullConBes(0) == false);
        }

        //пример 7. Минимальное количество маршрутов для удаления
        {
            TsNet tn(6, 3);
            tn.addRoute(0, {0, 1, 2});
            tn.addRoute(1, {2, 3, 4});
            tn.addRoute(2, {4, 5});
            assert(tn.FullCon() == true);
            assert(tn.mRTD() == 1);
        }

        cout << "Все тесты пройдены!" << endl;
    }
};

int main() {
    int n, m;
    cout << "Введите количество остановок (N) и количество маршрутов (M): ";
    cin >> n >> m;
    TsNet tn(n, m);

    for (int i = 0; i < m; ++i) {
        int k;
        cout << "Введите количество остановок " << i + 1 << ": ";
        cin >> k;
        vector<int> route(k);
        cout << "Введите остановки: ";
        for (int j = 0; j < k; ++j) {
            cin >> route[j];
        }
        tn.addRoute(i, route);
    }

    tn.runTests(); //Запустите предопределенные тестовые случаи, чтобы проверить правильность

    return 0;
}