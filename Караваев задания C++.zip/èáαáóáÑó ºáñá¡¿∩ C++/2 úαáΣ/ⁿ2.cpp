#include <iostream>
#include <list>
#include <queue>
#include <vector>
#include <limits>
#include <algorithm>
using namespace std;



class Graph {
private:
    int numVert;
    list<int> *aList;
    bool *visit;

public:
    Graph(int V);
    void addEdge(int src, int dest);
    void BFS(int startV);
    vector<int> sPath(int startV, int endV);
    vector<int> sCycle();
    vector<vector<int>> compon();
};



Graph::Graph(int vert) {
    numVert = vert;
    aList = new list<int>[vert];
    visit = new bool[vert];
    for (int i = 0; i < vert; ++i) {
        visit[i] = false;
    }
}




void Graph::addEdge(int src, int dest) {
    aList[src].push_back(dest);
}



void Graph::BFS(int startV) {
    queue<int> bfsQueue;
    visit[startV] = true;
    bfsQueue.push(startV);
    while (!bfsQueue.empty()) {
        int cVer = bfsQueue.front();
        cout << cVer << " ";
        bfsQueue.pop();
        for (auto i = aList[cVer].begin(); i != aList[cVer].end(); ++i) {
            if (!visit[*i]) {
                visit[*i] = true;
                bfsQueue.push(*i);
            }
        }
    }
}



//алгоритм поиска кратчайшего пути
vector<int> Graph::sPath(int startV, int endV) {
    vector<int> dist(numVert, numeric_limits<int>::max());
    vector<int> parent(numVert, -1);
    queue<int> bfsQueue;
    dist[startV] = 0;
    bfsQueue.push(startV);
    while (!bfsQueue.empty()) {
        int cVer = bfsQueue.front();
        bfsQueue.pop();
        for (auto i = aList[cVer].begin(); i != aList[cVer].end(); ++i) {
            if (dist[*i] == numeric_limits<int>::max()) {
                dist[*i] = dist[cVer] + 1;
                parent[*i] = cVer;
                bfsQueue.push(*i);
            }
        }
    }
    vector<int> path;
    int curr = endV;
    while (curr != -1) {
        path.push_back(curr);
        curr = parent[curr];
    }
    reverse(path.begin(), path.end());
    
    return path;
}



//алгоритм поиска кратчайшего цикла
vector<int> Graph::sCycle() {
    int Cyclen = numeric_limits<int>::max();
    vector<int> sCycle;
    for (int i = 0; i < numVert; ++i) {
        fill(visit, visit + numVert, false);
        queue<pair<int, int>> bfsQueue;
        bfsQueue.push({i, i});
        visit[i] = true;
        while (!bfsQueue.empty()) {
            int cVer = bfsQueue.front().first;
            int startV = bfsQueue.front().second;
            bfsQueue.pop();
            for (auto neighbor : aList[cVer]) {
                if (!visit[neighbor]) {
                    visit[neighbor] = true;
                    bfsQueue.push({neighbor, startV});
                } else if (neighbor == startV) {
                    vector<int> cycle;
                    cycle.push_back(cVer);
                    cycle.push_back(neighbor);
                    if (cycle.size() < Cyclen) {
                        Cyclen = cycle.size();
                        sCycle = cycle;
                    }
                    break;
                }
            }
        }
    }

    return sCycle;
}



//алгоритм поиска компонент связности
vector<vector<int>> Graph::compon() {
    vector<vector<int>> components;
    fill(visit, visit + numVert, false);
    for (int i = 0; i < numVert; ++i) {
        if (!visit[i]) {
            vector<int> component;
            queue<int> bfsQueue;
            visit[i] = true;
            bfsQueue.push(i);
            while (!bfsQueue.empty()) {
                int cVer = bfsQueue.front();
                component.push_back(cVer);
                bfsQueue.pop();
                for (auto neighbor : aList[cVer]) {
                    if (!visit[neighbor]) {
                        visit[neighbor] = true;
                        bfsQueue.push(neighbor);
                    }
                }
            }
            components.push_back(component);
        }
    }
    return components;
}



int main() {
    int numVert, numEdges;
    cout << "Введите количество вершин: ";
    cin >> numVert;
    cout << "Введите количество рёбер: ";
    cin >> numEdges;
    Graph g(numVert);
    int src, dest;
    cout << "Введите рёбра:" << endl;
    for (int i = 0; i < numEdges; ++i) {
        cin >> src >> dest;
        g.addEdge(src, dest);
    }



    int choice;
    do {
        cout << "\nМеню:\n";
        cout << "1. Обход в ширину\n";
        cout << "2. Поиск кратчайшего пути\n";
        cout << "3. Поиск кратчайшего цикла\n";
        cout << "4. Поиск компонент связности\n";
        cout << "5. Выход\n";
        cout << "Выбрать действие: ";
        cin >> choice;
        switch (choice) {
            case 1: {
                int startV;
                cout << "Введите начальную вершину для обхода в ширину: ";
                cin >> startV;
                cout << "Результат обхода в ширину: ";
                g.BFS(startV);
                break;
            }
            case 2: {
                int startV, endV;
                cout << "Введите начальную и конечную вершины для поиска кратчайшего пути: ";
                cin >> startV >> endV;
                vector<int> path = g.sPath(startV, endV);
                cout << "Кратчайший путь: ";
                for (int vertex : path) {
                    cout << vertex << " ";
                }
                cout << endl;
                break;
            }
            case 3: {
                vector<int> cycle = g.sCycle();
                cout << "Кратчайший цикл: ";
                for (int vertex : cycle) {
                    cout << vertex << " ";
                }
                cout << endl;
                break;
            }
            case 4: {
                vector<vector<int>> components = g.compon();
                cout << "Компоненты связности:\n";
                for (const auto& component : components) {
                    for (int vertex : component) {
                        cout << vertex << " ";
                    }
                    cout << endl;
                }
                break;
            }
            case 5:
                cout << "Конец\n";
                break;
            default:
                cout << "Неверный выбор. Попробуйте ещё раз.\n";
                break;
        }
    } while (choice != 5);

    return 0;
}
