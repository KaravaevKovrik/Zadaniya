#include <iostream>
#include <list>
#include <stack>
#include <vector>
#include <unordered_set>
using namespace std;

class Graph {
private:
    int numVer;
    list<int> *List;
    bool *visited;
    vector<int> color;
    vector<int> path; //храним текущий путь
    bool Cycle;
    unordered_set<int> curre; 



public:
    Graph(int V);
    void addEdge(int src, int dest);
    void DFS_it(int startV);
    void DFS_rec(int startV);
    void resetV(); 
    bool Bipa();
    bool CycleDFS();
    void pGraph();
    void inputData();
    ~Graph(); //деструктор для освобождения памяти
};


Graph::Graph(int vert) {
    numVer = vert;
    List = new list<int>[vert];
    visited = new bool[vert];
    color.resize(vert, -1); //вектор цветов
    resetV();
}

void Graph::addEdge(int src, int dest) {
    List[src].push_front(dest);
}



//DFS с использованием стека 
void Graph::DFS_it(int startV) {
    stack<int> stack;
    stack.push(startV);
    visited[startV] = true;
    while (!stack.empty()) {
        int currVert = stack.top();
        stack.pop();
        cout << currVert << " ";
        for (int Vertex : List[currVert]) {
            if (!visited[Vertex]) {
                stack.push(Vertex);
                visited[Vertex] = true;
            }
        }
    }
}

//DFS с использованием рекурсии
void Graph::DFS_rec(int startV) {
    visited[startV] = true;
    cout << startV << " ";
    for (int Vertex : List[startV]) {
        if (!visited[Vertex]) {
            DFS_rec(Vertex);
        }
    }
}
void Graph::resetV() {
    for (int i = 0; i < numVer; ++i) {
        visited[i] = false;
    }
}



//проверка на двудольность графа
bool Graph::Bipa() {
    stack<int> stack;
    for (int i = 0; i < numVer; ++i) {
        if (!visited[i]) {
            stack.push(i);
            color[i] = 0; 
            visited[i] = true;
            while (!stack.empty()) {
                int currVert = stack.top();
                stack.pop();
                for (int Vertex : List[currVert]) {
                    if (!visited[Vertex]) {
                        color[Vertex] = 1 - color[currVert];
                        stack.push(Vertex);
                        visited[Vertex] = true;
                    } else if (color[Vertex] == color[currVert]) {
                        return false;
                    }
                }
            }
        }
    }
    return true;
}

//поиск цикла в ориентированном графе
bool Graph::CycleDFS() {
    Cycle = false;
    for (int i = 0; i < numVer; ++i) {
        if (!visited[i]) {
            path.clear();
            curre.clear();
            DFS_rec(i); 
            if (Cycle) return true;
        }
    }
    return false;
}



//вывод графа в виде списков смежности
void Graph::pGraph() {
    for (int i = 0; i < numVer; ++i) {
        cout << "вершина " << i << ": ";
        for (int v : List[i]) {
            cout << v << " ";
        }
        cout << endl;
    }
}




void Graph::inputData() {
    int numEdges;
    cout << "Введите количество рёбер: ";
    cin >> numEdges;

    int src, dest;
    cout << "Введите рёбра:" << endl;
    for (int i = 0; i < numEdges; ++i) {
        cin >> src >> dest;
        addEdge(src, dest);
    }
}
Graph::~Graph() {
    delete[] List;
    delete[] visited;
}




int main() {
    Graph g(0); 
    int numVer;
    cout << "Введите количество вершин: ";
    cin >> numVer;
    g = Graph(numVer); 
    g.inputData(); 
    cout << "Представление графа в виде списков смежности:" << endl;
    g.pGraph();
    int startV;
    cout << "Введите начальную вершину: ";
    cin >> startV;
    cout << "Результат обхода в глубину(нерекурсивная): ";
    g.DFS_it(startV);
    cout << endl;
    g.resetV(); 
    cout << "Результат обхода в глубину(рекурсивная): ";
    g.DFS_rec(startV);
    cout << endl;

    //проверяем на двудольность
    if (g.Bipa()) {
        cout << "Граф является двудольным." << endl;
    } else {
        cout << "Граф не является двудольным." << endl;
    }

    //проверяем на наличие цикла
    if (g.CycleDFS()) {
        cout << "Граф содержит цикл." << endl;
    } else {
        cout << "Граф не содержит циклов." << endl;
    }

    return 0;
}
