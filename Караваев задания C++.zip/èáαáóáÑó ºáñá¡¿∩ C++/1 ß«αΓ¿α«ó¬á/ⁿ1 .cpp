#include <iostream>
#include <vector>
#include <string>
#include <random>
#include <algorithm>

using namespace std;

class Record {
public:
    string fname;
    string dr;
    int brain;
    Record(string name, string dr, int volume) : fname(name), dr(dr), brain(volume) {}
    void display() const {
        cout << "Имя: " << fname << endl;
        cout << "День Рождения: " << dr << endl;
        cout << "Объем мозга: " << brain<< endl;
    }
    bool operator<(const Record& other) const {
        return fname < other.fname;
    }
    bool compare(const Record& other, int sortField) const {
        switch(sortField) {
            case 1: 
                return fname < other.fname;
            case 2: 
                return dr < other.dr;
            case 3:
                return brain < other.brain;
            default:
                return false; 
        }
    }
};




class RCont{
private:
    vector<Record> records;
public:
    void addRecord(const Record& record) {
        records.push_back(record);
    }
    void displayR() const {
        for (size_t i = 0; i < records.size(); ++i) {
            cout << "Запись " << i + 1 << endl;
            records[i].display();
            cout << endl;
        }
    }

    void NewR() {
        string name, dr;
        int volume;
        cout << "Введите имя: ";
        getline(cin, name);
        cout << "Введите Дату Рождения (Д.М.Г): ";
        getline(cin, dr);
        cout << "Введите Объем мозга: ";
        cin >> volume;
        cin.ignore();

        Record record(name, dr, volume);
        addRecord(record);
    }



    //методо пузырьком 
    void bubbleSort(int sortField) {
        int n = records.size();
        for (int i = 0; i < n - 1; ++i) {
            for (int j = 0; j < n - i - 1; ++j) {
                if (!records[j].compare(records[j + 1], sortField)) {
                    swap(records[j], records[j + 1]);
                }
            }
        }
    }
    //сортировка выбором
    void selectionSort(int sortField) {
        int n = records.size();
        for (int i = 0; i < n - 1; ++i) {
            int minIndex = i;
            for (int j = i + 1; j < n; ++j) {
                if (records[j].compare(records[minIndex], sortField)) {
                    minIndex = j;
                }
            }
            if (minIndex != i) {
                swap(records[i], records[minIndex]);
            }
        }
    }
    //сортировка вставками
    void insertionSort(int sortField) {
        int n = records.size();
        for (int i = 1; i < n; ++i) {
            Record key = records[i];
            int j = i - 1;
            while (j >= 0 && !records[j].compare(key, sortField)) {
                records[j + 1] = records[j];
                --j;
            }
            records[j + 1] = key;
        }
    }
    //быстрая сортировка
    void quickSort(int sortField, int low, int high) {
        if (low < high) {
            int pi = part(sortField, low, high);
            quickSort(sortField, low, pi - 1);
            quickSort(sortField, pi + 1, high);
        }
    }
    //сортировка перемешиванием
    void cocktailSort(int sortField) {
        int left = 0;
        int right = records.size() - 1;
        bool swapped = true;
        while (swapped) {
            swapped = false;
            for (int i = left; i < right; ++i) {
                if (records[i].compare(records[i + 1], sortField)) {
                    swap(records[i], records[i + 1]);
                    swapped = true;
                }
            }
            if (!swapped) break;
            --right;
            for (int i = right; i > left; --i) {
                if (records[i - 1].compare(records[i], sortField)) {
                    swap(records[i - 1], records[i]);
                    swapped = true;
                }
            }
            ++left;
        }
    }
    

    
    //сортировка расчесткой
    void combSort(int sortField) {
        int n = records.size();
        int gap = n;
        float shrink = 1.3;
        bool sorted = false;
        while (!sorted) {
            gap = static_cast<int>(gap / shrink);
            if (gap > 1) {
                sorted = false;
            } else {
                gap = 1;
                sorted = true;
            }
            int i = 0;
            while (i + gap < n) {
                if (records[i].compare(records[i + gap], sortField)) {
                    swap(records[i], records[i + gap]);
                    sorted = false;
                }
                ++i;
            }
        }
    }



private:


    int part(int sortField, int low, int high) {
        Record pivot = records[high];
        int i = low - 1;
        for (int j = low; j < high; ++j) {
            if (records[j].compare(pivot, sortField)) {
                ++i;
                swap(records[i], records[j]);
            }
        }
        swap(records[i + 1], records[high]);
        return i + 1;
    }
    
public:
    size_t size() const {
        return records.size();
    }
    void shellSort(int sortField) {
        int n = records.size();
        for (int gap = n / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < n; ++i) {
                Record temp = records[i];
                int j;
                for (j = i; j >= gap && records[j - gap].compare(temp, sortField); j -= gap) {
                    records[j] = records[j - gap];
                }
                records[j] = temp;
            }
        }
    }
    
    
    //пирамидальная
    void heapSort(int sortField) {
        int n = records.size();
        for (int i = n / 2 - 1; i >= 0; --i) {
            heapify(sortField, n, i);
        }
        for (int i = n - 1; i > 0; --i) {
            swap(records[0], records[i]);
            heapify(sortField, i, 0);
        }
    }


private:
    void heapify(int sortField, int n, int i) {
        int larg = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        if (left < n && records[left].compare(records[larg], sortField)) {
            larg = left;
        }
        if (right < n && records[right].compare(records[larg], sortField)) {
            larg = right;
        }
        if (larg != i) {
            swap(records[i], records[larg]);
            heapify(sortField, n, larg);
        }
    }
    
    
    
    //пробуем генерировать
    string genDR() const {
        const vector<string> months = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
        random_device rd;
        mt19937 gen(rd());
        uniform_int_distribution<int> distribution(1, 28);
        int day = distribution(gen);
        uniform_int_distribution<int> monthDist(0, 11);
        string month = months[monthDist(gen)];
        uniform_int_distribution<int> yearDist(1950, 2020);
        int year = yearDist(gen);
        return to_string(day) + "." + month + "." + to_string(year);
    }

    string genName() const {
        const vector<string> names = {"Алексей", "Ваня", "Катя", "Дмитрий", "Лена", "Костя", "Владимир", "Томас", "Гурам", "Андрей"};
        random_device rd;
        mt19937 gen(rd());
        uniform_int_distribution<int> distribution(0, names.size() - 1);
        int index = distribution(gen);
        return names[index];
    }



public:
    void RRecords(size_t count) {
        for (size_t i = 0; i < count; ++i) {
            string name = genName();
            string dr = genDR();
            int volume = rand() % 2000 + 1000;
            Record record(name, dr, volume);
            addRecord(record);
        }
    }
    
    
    
    
};


int main() {
    RCont container;
    int choice;

    
    container.RRecords(100);

    do {
        cout << "Меню.:" << endl;
        cout << "1. Смотреть список" << endl;
        cout << "2. Введите новые данные" << endl;
        cout << "3. Сортировка пузырьком" << endl;
        cout << "4. Сортировка выбором" << endl;
        cout << "5. Сортировка вставкой" << endl;
        cout << "6. Быстрая сортирвка" << endl;
        cout << "7. Сортировка Шеллом" << endl;
        cout << "8. Кучная сортировка" << endl;
        cout << "9. Сортировка перемешиванием" << endl;
        cout << "10. Сортировка расчесткой" << endl;
        cout << "0. Выход" << endl;
        cout << "Выберите пункт: ";
        cin >> choice;
        cin.ignore();



        switch(choice) {
            case 1:
                cout << "Все записи:" << endl;
                container.displayR();
                break;
            case 2:
                container.NewR();
                break;
            case 3:
                int sortField;
                cout << "Выберите поле сортировки:" << endl;
                cout << "1. По имени" << endl;
                cout << "2. По ДР" << endl;
                cout << "3. По объему мозга" << endl;
                cout << "Выберите пункт: ";
                cin >> sortField;
                cin.ignore();
                container.bubbleSort(sortField);
                cout << "Выполнено." << endl;
                break;
            case 4:
                cout << "Выберите поле сортировки:" << endl;
                cout << "1. По имени" << endl;
                cout << "2. По ДР" << endl;
                cout << "3. По объему мозга" << endl;
                cout << "Выполнено ";
                cin >> sortField;
                cin.ignore(); 
                break;
            case 5:
                cout << "Выберите поле сортировки:" << endl;
                cout << "1. По имени" << endl;
                cout << "2. По ДР" << endl;
                cout << "3. По объему мозга" << endl;
                cout << "Выберите пункт: ";
                cin >> sortField;
                cin.ignore(); 
                if (choice == 3) {
                    container.bubbleSort(sortField);
                    cout << "Записи отсортированы по пузырьку." << endl;
                } else if (choice == 4) {
                    container.selectionSort(sortField);
                    cout << "Записи отсортированы по выбору." << endl;
                } else {
                    container.insertionSort(sortField);
                    cout << "Записи отсортированы по вставке." << endl;
                }
                break;
            case 6:
                int quickSortField;
                cout << "Выберите поле сортировки:" << endl;
                cout << "1. По имени" << endl;
                cout << "2. По ДР" << endl;
                cout << "3. По объему мозга" << endl;
                cout << "Выполнено ";
                cin >> quickSortField;
                cin.ignore();
                container.quickSort(quickSortField, 0, container.size() - 1);
                cout << "Записи отсортированы быстрой сортировкой." << endl;
                break;
            case 7:
                int shellSortField;
                cout << "Выберите поле сортировки:" << endl;
                cout << "1. По имени" << endl;
                cout << "2. По ДР" << endl;
                cout << "3. По объему мозга" << endl;
                cout << "Выполнено ";
                cin >> shellSortField;
                cin.ignore(); 
                container.shellSort(shellSortField);
                cout << "Отсортированы методом Шелла." << endl;
                break;
            case 8:
                int heapSortField;
                cout << "Выберите поле сортировки:" << endl;
                cout << "1. По имени" << endl;
                cout << "2. По ДР" << endl;
                cout << "3. По объему мозга" << endl;
                cout << "Выполнено ";
                cin >> heapSortField;
                cin.ignore(); 
                container.heapSort(heapSortField);
                cout << "С помощью пирамидальной сортировки" << endl;
                break;
            case 9:
                int cocktailSortField;
                cout << "Выберите поле сортировки:" << endl;
                cout << "1. По имени" << endl;
                cout << "2. По ДР" << endl;
                cout << "3. По объему мозга" << endl;
                cout << "Выполнено ";
                cin >> cocktailSortField;
                cin.ignore(); 
                container.cocktailSort(cocktailSortField);
                cout << "С помощью сортировки перемешивания." << endl;
                break;
            case 10:
                int combSortField;
                cout << "Выберите поле сортировки:" << endl;
                cout << "1. По имени" << endl;
                cout << "2. По ДР" << endl;
                cout << "3. По объему мозга" << endl;
                cout << "Выполнено ";
                cin >> combSortField;
                cin.ignore(); 
                container.combSort(combSortField);
                cout << "С помощью сортировки расчесткой." << endl;
                break;
            case 0:
                cout << "Выход...." << endl;
                break;
            default:
                cout << "Ошибка. попробуйте еще раз" << endl;
        }
    } while (choice != 0);

    return 0;
}
