#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <windows.h>

class MultiplTree {
private:
    std::string name;
    std::string value;
    std::vector<MultiplTree> children;

public:
    void setName(const std::string& newName) {
        name = newName;
    }

    std::string getName() const {
        return name;
    }

    void setValue(const std::string& newValue) {
        value = newValue;
    }

    void setValue(double newValue) {
        value = std::to_string(newValue);
    }

    void setValue(int newValue) {
        value = std::to_string(newValue);
    }

    std::string getValue() const {
        return value;
    }

    bool isInt() const {
        if (value.empty()) return false;
        char* end;
        long val = std::strtol(value.c_str(), &end, 10);
        return *end == '\0';
    }

    bool isDouble() const {
        if (value.empty()) return false;
        char* end;
        double val = std::strtod(value.c_str(), &end);
        return *end == '\0';
    }

    int getInt() const {
        if (isInt()) return std::stoi(value);
        return 0;
    }

    double getDouble() const {
        if (isDouble()) return std::stod(value);
        return 0.0;
    }

    int getCountSub() const {
        return children.size();
    }

    MultiplTree* getSub(int index) {
        if (index >= 0 && index < children.size()) {
            return &children[index];
        }
        return nullptr;
    }

    MultiplTree* getSub(const std::string& childName) {
        for (auto& child : children) {
            if (child.getName() == childName) {
                return &child;
            }
        }
        return nullptr;
    }

    void addSub(const MultiplTree& child) {
        children.push_back(child);
    }

    MultiplTree* fiName(const std::string& nodeName) {
        if (name == nodeName) {
            return this;
        }
        for (auto& child : children) {
            MultiplTree* result = child.fiName(nodeName);
            if (result) {
                return result;
            }
        }
        return nullptr;
    }

    void loadXml(std::istream& is) {
        std::string line;
        std::getline(is, line); 
        loadXmlHel(is);
    }

    void loadXmlHel(std::istream& is) {
        std::string line;
        while (std::getline(is, line)) {
            line = trim(line);
            if (line.empty() || line.front() != '<' || line[1] == '/') {
                if (!line.empty() && line.front() == '<' && line[1] == '/') {
                    break;
                }
                continue;
            }

            std::string tagName = TName(line);
            std::string tagValue = TValue(line);

            MultiplTree child;
            child.setName(tagName);

            if (!(line.back() == '/' || (line.back() == '>' && line[line.size() - 2] == '/'))) {
                child.setValue(tagValue);
                child.loadXmlHel(is);
            } else {
                child.setValue(tagValue);
            }

            addSub(child);
        }
    }

    std::string trim(const std::string& str) {
        size_t start = str.find_first_not_of(" \t\n\r");
        size_t end = str.find_last_not_of(" \t\n\r");
        if (start == std::string::npos || end == std::string::npos) {
            return "";
        }
        return str.substr(start, end - start + 1);
    }

    std::string TName(const std::string& line) {
        size_t start = line.find('<') + 1;
        size_t end = line.find_first_of(" />", start);
        return line.substr(start, end - start);
    }

    std::string TValue(const std::string& line) {
        size_t start = line.find('>') + 1;
        size_t end = line.rfind('<');
        if (start < end) {
            return line.substr(start, end - start);
        }
        return "";
    }

    void printDataF() const {
        std::vector<std::string> printedValues;
        printDataFHel(printedValues);
        for (const auto& child : children) {
            child.printDataFHel(printedValues);
        }
    }

    void printDataFHel(std::vector<std::string>& printedValues) const {
        if ((name == "brand" || name == "color" || name == "model" || name == "price" || name == "url" || name == "memory") &&
            std::find(printedValues.begin(), printedValues.end(), name + value) == printedValues.end()) {
            std::cout << name << ": " << value << std::endl;
            printedValues.push_back(name + value);
        }
        for (const auto& child : children) {
            child.printDataFHel(printedValues);
        }
    }

    void updateValue(const std::string& targetName, const std::string& newValue) {
        if (name == targetName) {
            value = newValue;
            return;
        }
        for (auto& child : children) {
            child.updateValue(targetName, newValue);
        }
    }

    void saveXmlHel(std::ostream& os, const MultiplTree& node, int indentLevel) const {
        std::string indentation(indentLevel * 4, ' '); 
        os << indentation << "<" << node.getName() << ">";
        if (!node.getValue().empty()) {
            os << node.getValue();
        }
        if (!node.children.empty()) {
            os << std::endl;
            for (const auto& child : node.children) {
                saveXmlHel(os, child, indentLevel + 1);
            }
            os << indentation;
        }
        os << "</" << node.getName() << ">" << std::endl;
    }

    void saveXml(const std::string& filename) const {
        std::ofstream file(filename);
        if (!file.is_open()) {
            std::cerr << "Ошибка с открытием." << std::endl;
            return;
        }
        file << "<?xml version=\"1.0\" encoding=\"windows-1251\"?>" << std::endl;
        saveXmlHel(file, *this, 1); 
        file.close();
    }
};

void displayMenu() {
    std::cout << "Меню:\n";
    std::cout << "1. Вывести\n";
    std::cout << "2. Редактировать\n";
    std::cout << "3. Сохранить\n";
    std::cout << "4. Выход\n";
    std::cout << "Ваш выбор: ";
}

int main() {
	SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);
    MultiplTree catalog;

    std::ifstream file("rec.xml");
    if (!file.is_open()) {
        std::cerr << "Ошибка с открытием." << std::endl;
        return 1;
    }

    catalog.loadXml(file);
    file.close();

    int choice;
    std::string filename = "rec.xml"; 

    do {
        displayMenu();
        std::cin >> choice;
        std::cin.ignore(); 
        std::string targetName;
        std::string newValue;
        switch (choice) {
            case 1:
                std::cout << "Каталог:" << std::endl;
                catalog.printDataF();
                break;
            case 2:
                std::cout << "Введите имя поля для редактирования: ";
                std::getline(std::cin, targetName);
                std::cout << "Введите новое значение: ";
                std::getline(std::cin, newValue);
                catalog.updateValue(targetName, newValue);
                std::cout << "Успешно." << std::endl;
                break;
            case 3:
                catalog.saveXml(filename);
                std::cout << "Данные успешно сохранены в XML." << std::endl;
                break;
            case 4:
                std::cout << "выход..." << std::endl;
                break;
            default:
                std::cout << "неправильный  выбор." << std::endl;
                break;
        }
    } while (choice != 4);

    return 0;
}
