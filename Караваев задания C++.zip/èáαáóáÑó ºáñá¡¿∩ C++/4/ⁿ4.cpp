#include <iostream>
#include <vector>
#include <string>
#include <limits>
#include <queue>
#include <unordered_map>
#include <unordered_set>

using namespace std;


struct Flight {
    string destination;
    int time;
    int cost;

    Flight(string dest, int t, int c) : destination(dest), time(t), cost(c) {}
};


class FlightSys {
private:
    unordered_map<string, vector<Flight>> flights; 
    

public:
//добавляем рейс в систему
    
    void addFlight(const string& source, const Flight& flight) {
        flights[source].push_back(flight);
    }
    

    //алгоритм Дейкстры для поиска кратчайшего пути по времени
    void DTime(const string& start) {
        unordered_map<string, int> time;
        priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;
        for (const auto& pair : flights) {
            time[pair.first] = numeric_limits<int>::max();
        }
        time[start] = 0;
        pq.push({0, start});
        while (!pq.empty()) {
            string city = pq.top().second;
            int currTime = pq.top().first;
            pq.pop();
            for (const Flight& flight : flights[city]) {
                int nextTime = currTime + flight.time;
                if (nextTime < time[flight.destination]) {
                    time[flight.destination] = nextTime;
                    pq.push({nextTime, flight.destination});
                }
            }
        }

        cout << "Кратчайшие пути из города (по времени) " << start << ":" << endl;
        for (const auto& pair : time) {
            cout << "город: " << pair.first << ", время: " << pair.second << " час." << endl;
        }
    }

    //алгоритм Дейкстры для поиска кратчайшего пути по стоимости
    void DCost(const string& start) {
        unordered_map<string, int> cost;
        priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;
        for (const auto& pair : flights) {
            cost[pair.first] = numeric_limits<int>::max();
        }
                cost[start] = 0;
        pq.push({0, start});
        while (!pq.empty()) {
            string city = pq.top().second;
            int currCost = pq.top().first;
            pq.pop();
            for (const Flight& flight : flights[city]) {
                int nextCost = currCost + flight.cost;
                if (nextCost < cost[flight.destination]) {
                    cost[flight.destination] = nextCost;
                    pq.push({nextCost, flight.destination});
                }
            }
        }
        cout << "Кратчайшие пути из города (по стоимости)" << start << ":" << endl;
        for (const auto& pair : cost) {
            cout << "город: " << pair.first << ", стоимость: " << pair.second << " руб." << endl;
        }
    }


    //алгоритм Дейкстры с списком городов
    vector<string> DCity(const string& start, int budget) {
        unordered_map<string, int> cost;
        priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;
        for (const auto& pair : flights) {
            cost[pair.first] = numeric_limits<int>::max();
        }
        cost[start] = 0;
        pq.push({0, start});
        while (!pq.empty()) {
            string city = pq.top().second;
            int currCost = pq.top().first;
            pq.pop();
            if (currCost > budget) continue; 
            for (const Flight& flight : flights[city]) {
                int nextCost = currCost + flight.cost;
                if (nextCost < cost[flight.destination]) {
                    cost[flight.destination] = nextCost;
                    pq.push({nextCost, flight.destination});
                }
            }
        }


        //список городов, в которые можно попасть с определееной суммой
        vector<string> dostig;
        for (const auto& pair : cost) {
            if (pair.second <= budget) {
                dostig.push_back(pair.first);
            }
        }

        return dostig;
    }

    //определяем, можно ли попасть из одного города в другой с двумя пересадками
    bool TWOTR(const string& start, const string& destin) {
        unordered_set<string> visited;
        queue<string> q;

        
        q.push(start);
        visited.insert(start);

        int price = 0;

        while (!q.empty()) {
            int size = q.size();
            for (int i = 0; i < size; ++i) {
                string current = q.front();
                q.pop();
                if (current == destin) {
                    if (price <= 2) return true;
                }
                for (const Flight& flight : flights[current]) {//добавляем в очередь города, которые не были посещены
                    if (visited.find(flight.destination) == visited.end()) {
                        q.push(flight.destination);
                        visited.insert(flight.destination);
                    }
                }
            }
            //увеличиваем количество пересадок
            ++price;
            if (price > 2) return false;
        }
        return false;
    }

    //аналогичная проверка, но с тремя пересадками
    bool THRTR(const string& start, const string& destin) {
        unordered_set<string> visited;
        queue<string> q;

        q.push(start);
        visited.insert(start);
        int price = 0;

        while (!q.empty()) {
            int size = q.size();
            for (int i = 0; i < size; ++i) {
                string current = q.front();
                q.pop();
                if (current == destin) {
                    if (price <= 3) return true;
                }
                for (const Flight& flight : flights[current]) {
                    if (visited.find(flight.destination) == visited.end()) {
                        q.push(flight.destination);
                        visited.insert(flight.destination);
                    }
                }
            }
            ++price;
            if (price > 3) return false;
        }

        return false;
    }
};

void displayMenu() {
    cout << "Меню:" << endl;
    cout << "1. Поиск кратчайших путей по времени" << endl;
    cout << "2. Поиск кратчайших путей по стоимости" << endl;
    cout << "3. Поиск списка городов по определенной сумме" << endl;
    cout << "4. Проверка возможности попадания с двумя пересадками" << endl;
    cout << "5. Проверка возможности попадания с тремя пересадками" << endl;
    cout << "6. Выход" << endl;
    cout << "Выбрать операцию: ";
}

int main() {
    FlightSys system;
    
    system.addFlight("Москва", Flight("Париж", 4, 300));
    system.addFlight("Москва", Flight("Париж", 3, 400));
    system.addFlight("Москва", Flight("Лондон", 4, 350));
    system.addFlight("Лондон", Flight("Нью-Йорк", 8, 600));
    system.addFlight("Лондон", Flight("Нью-Йорк", 7, 700));
    system.addFlight("Париж", Flight("Токио", 12, 800));


    int choice;
    while (true) {
        displayMenu();
        cin >> choice;

        switch (choice) {
            case 1:
                system.DTime("Москва");
                break;
            case 2:
                system.DCost("Москва");
                break;
            case 3:
                int budget;
                cout << "Введите бюджет: ";
                cin >> budget;
                cout << "Список городов, в которые можно попасть из Москвы с бюджетом " << budget << " руб:" << endl;
                {
                    vector<string> dostig = system.DCity("Москва", budget);
                    for (const string& city : dostig) {
                        cout << city << endl;
                    }
                }
                break;
            case 4:
                if (system.TWOTR("Москва", "Токио")) {
                    cout << "Можно попасть из Москвы в Токио с двумя пересадками." << endl;
                } else {
                    cout << "Нельзя попасть из Москвы в Токио с двумя пересадками." << endl;
                }
                break;
            case 5:
                if (system.THRTR("Москва", "Токио")) {
                    cout << "Можно попасть из Москвы в Токио с тремя пересадками." << endl;
                } else {
                    cout << "Нельзя попасть из Москвы в Токио с тремя пересадками." << endl;
                }
                break;
            case 6:
                cout << "Выход" << endl;
                return 0;
            default:
                cout << "Неверный выбор. Попробуйте снова." << endl;
        }
    }

    return 0;
}
